class EmployeeClient {
  getRoutePrefix() {
    var isProd = window.location.href.includes("Prod");
    var isStage = window.location.href.includes("Stage");

    if (isProd === true) {
      return "/Prod/";
    }

    if (isStage === true) {
      return "/Stage/";
    }

    return "/";
  }

  get(done) {
    $.ajax({
      method: "GET",
      url: this.getRoutePrefix() + "api/employees",
      headers: {
        'Content-Type': 'application/json; charset=utf-8'
      },
      dataType: 'json'
    })
    .done(function(data) {
      done(data);
    });
  }

  add(firstName, lastName, dependants, done) {
    $.ajax({
      method: "POST",
      url: this.getRoutePrefix() + "api/employees",
      headers: {
        'Content-Type': 'application/json; charset=utf-8'
      },
      dataType: 'json',
      data: JSON.stringify({
        firstName: firstName,
        lastName: lastName,
        dependants: dependants
      })
    })
    .done(function () {
      done();
    });
  }

  delete(id, done) {
    $.ajax({
      method: "DELETE",
      url: this.getRoutePrefix() + "api/employees/" + id
    })
    .done(function () {
      done();
    });
  }

  update(id, firstName, lastName, dependants, done) {
    $.ajax({
      method: "PUT",
      url: this.getRoutePrefix() + "api/employees",
      headers: {
        'Content-Type': 'application/json; charset=utf-8'
      },
      data: JSON.stringify({
        id: id,
        firstName: firstName,
        lastName: lastName,
        dependants: dependants
      })
    })
    .done(function () {
      done();
    });
  }
}
